<?php
define('BASE_URL', 'http://localhost/parkir/public');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_parkir');
