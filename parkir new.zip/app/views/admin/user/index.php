<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
    <h2>Kelola User</h2>
    <button class="btn-primary" onclick="document.getElementById('formUser').style.display='block'; window.scrollTo(0,0);">
        <i class="fa-solid fa-plus"></i> Tambah User
    </button>
</div>

<div id="formUser" class="form-section glass-panel" style="display: none;">
    <h3><i class="fa-solid fa-user-plus"></i> Form Tambah User</h3>
    <form action="<?= BASE_URL ?>/user/tambah" method="POST" style="margin-top: 15px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
            <div>
                <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Nama Lengkap</label>
                <input type="text" name="nama_lengkap" required style="width:100%; padding:10px; border-radius:5px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
            </div>
            <div>
                <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Username</label>
                <input type="text" name="username" required style="width:100%; padding:10px; border-radius:5px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
            </div>
            <div>
                <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Password</label>
                <input type="password" name="password" required style="width:100%; padding:10px; border-radius:5px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
            </div>
            <div>
                <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Role</label>
                <select name="role" required style="width:100%; padding:10px; border-radius:5px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
                    <option value="admin" style="background:#1e293b;">Admin</option>
                    <option value="petugas" style="background:#1e293b;">Petugas</option>
                    <option value="owner" style="background:#1e293b;">Owner</option>
                </select>
            </div>
            <div>
                <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Status Akun</label>
                <select name="status_aktif" required style="width:100%; padding:10px; border-radius:5px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
                    <option value="1" style="background:#1e293b;">Aktif</option>
                    <option value="0" style="background:#1e293b;">Non-aktif</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn-primary">Simpan User</button>
        <button type="button" class="btn-primary" style="background:var(--danger)" onclick="document.getElementById('formUser').style.display='none'">Batal</button>
    </form>
</div>

<!-- Modal Edit User -->
<div id="modalEditUser" class="modal">
    <div class="modal-content glass-panel">
        <div class="modal-header">
            <h3 class="modal-title"><i class="fa-solid fa-user-pen"></i> Edit User</h3>
            <span class="modal-close" onclick="closeModal('modalEditUser')">&times;</span>
        </div>
        <form id="formEditUser" method="POST">
            <input type="hidden" name="id_user" id="edit_id_user">
            <div class="form-grid">
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Nama Lengkap</label>
                    <input type="text" name="nama_lengkap" id="edit_nama_lengkap" required style="width:100%; padding:10px; border-radius:8px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Username</label>
                    <input type="text" name="username" id="edit_username" required style="width:100%; padding:10px; border-radius:8px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Password <small>(Isi jika ingin ubah)</small></label>
                    <input type="password" name="password" style="width:100%; padding:10px; border-radius:8px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Role</label>
                    <select name="role" id="edit_role" required style="width:100%; padding:10px; border-radius:8px; background:rgba(15, 23, 42, 0.8); border:1px solid var(--border-color); color:#fff;">
                        <option value="admin">Admin</option>
                        <option value="petugas">Petugas</option>
                        <option value="owner">Owner</option>
                    </select>
                </div>
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Status</label>
                    <select name="status_aktif" id="edit_status" required style="width:100%; padding:10px; border-radius:8px; background:rgba(15, 23, 42, 0.8); border:1px solid var(--border-color); color:#fff;">
                        <option value="1">Aktif</option>
                        <option value="0">Non-aktif</option>
                    </select>
                </div>
            </div>
            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;">
                <button type="button" class="btn-primary" style="background:var(--danger)" onclick="closeModal('modalEditUser')">Batal</button>
                <button type="submit" class="btn-primary">Update Data</button>
            </div>
        </form>
    </div>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>No</th><th>Nama Lengkap</th><th>Username</th><th>Role</th><th>Status</th><th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; foreach($data['users'] as $u): ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><?= htmlspecialchars($u['nama_lengkap']) ?></td>
                <td><?= htmlspecialchars($u['username']) ?></td>
                <td><span class="badge"><?= ucfirst($u['role']) ?></span></td>
                <td><?= $u['status_aktif'] ? '<span class="badge" style="background:var(--success)">Aktif</span>' : '<span class="badge" style="background:var(--danger)">Non-aktif</span>' ?></td>
                <td>
                    <?php if($u['id_user'] != $_SESSION['user_parkir']['id_user']): ?>
                    <button class="btn-primary" style="background:var(--warning); padding:5px 10px; font-size:0.8rem;" onclick="openEditUser(<?= $u['id_user'] ?>, '<?= htmlspecialchars(addslashes($u['nama_lengkap'])) ?>', '<?= htmlspecialchars(addslashes($u['username'])) ?>', '<?= $u['role'] ?>', '<?= $u['status_aktif'] ?>')">
                        <i class="fa-solid fa-edit"></i>
                    </button>
                    <a href="<?= BASE_URL ?>/user/hapus/<?= $u['id_user'] ?>" class="btn-primary" style="background:var(--danger); padding:5px 10px; font-size:0.8rem;" onclick="return confirm('Yakin hapus?');">
                        <i class="fa-solid fa-trash"></i>
                    </a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
function openEditUser(id, nama, username, role, status) {
    document.getElementById('edit_id_user').value = id;
    document.getElementById('edit_nama_lengkap').value = nama;
    document.getElementById('edit_username').value = username;
    document.getElementById('edit_role').value = role;
    document.getElementById('edit_status').value = status;
    document.getElementById('modalEditUser').style.display = 'block';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
}

// Handle AJAX Update
document.getElementById('formEditUser').onsubmit = function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('<?= BASE_URL ?>/user/ubah', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.status === 'success') {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: data.message,
                background: '#1e293b',
                color: '#fff',
                confirmButtonColor: '#6366f1'
            }).then(() => {
                location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.message,
                background: '#1e293b',
                color: '#fff'
            });
        }
    });
};

// Close modal when clicking outside
window.onclick = function(event) {
    if (event.target.className === 'modal') {
        event.target.style.display = 'none';
    }
}
</script>
