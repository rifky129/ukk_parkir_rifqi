<div style="margin-bottom: 20px;">
    <h2>Data Kendaraan Terdaftar</h2>
    <p style="color:var(--text-muted);">Data ini dibuat otomatis saat Petugas menginput kendaraan masuk yang baru.</p>
</div>

<!-- Modal Edit Kendaraan -->
<div id="modalEditKendaraan" class="modal">
    <div class="modal-content glass-panel">
        <div class="modal-header">
            <h3 class="modal-title"><i class="fa-solid fa-car"></i> Edit Data Kendaraan</h3>
            <span class="modal-close" onclick="closeModal('modalEditKendaraan')">&times;</span>
        </div>
        <form id="formEditKendaraan" method="POST">
            <input type="hidden" name="id_kendaraan" id="edit_id_kendaraan">
            <div class="form-grid">
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Plat Nomor</label>
                    <input type="text" name="plat_nomor" id="edit_plat_nomor" required style="width:100%; padding:10px; border-radius:8px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Jenis Kendaraan</label>
                    <select name="jenis_kendaraan" id="edit_jenis_kendaraan" required style="width:100%; padding:10px; border-radius:8px; background:rgba(15, 23, 42, 0.8); border:1px solid var(--border-color); color:#fff;">
                        <option value="mobil">Mobil</option>
                        <option value="motor">Motor</option>
                    </select>
                </div>
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Warna</label>
                    <input type="text" name="warna" id="edit_warna" required style="width:100%; padding:10px; border-radius:8px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
                </div>
                <div>
                    <label style="display:block; margin-bottom:5px; color:var(--text-muted);">Nama Pemilik</label>
                    <input type="text" name="pemilik" id="edit_pemilik" required style="width:100%; padding:10px; border-radius:8px; background:rgba(0,0,0,0.2); border:1px solid var(--border-color); color:#fff;">
                </div>
            </div>
            <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;">
                <button type="button" class="btn-primary" style="background:var(--danger)" onclick="closeModal('modalEditKendaraan')">Batal</button>
                <button type="submit" class="btn-primary">Update Kendaraan</button>
            </div>
        </form>
    </div>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr><th>No</th><th>Plat Nomor</th><th>Jenis</th><th>Warna</th><th>Pemilik</th><th>Aksi</th></tr>
        </thead>
        <tbody>
            <?php $i = 1; foreach($data['kendaraan'] as $k): ?>
            <tr>
                <td><?= $i++ ?></td>
                <td style="font-weight:bold;"><?= htmlspecialchars($k['plat_nomor']) ?></td>
                <td><?= ucfirst($k['jenis_kendaraan']) ?></td>
                <td><?= htmlspecialchars($k['warna']) ?></td>
                <td><?= htmlspecialchars($k['pemilik']) ?></td>
                <td>
                    <button class="btn-primary" style="background:var(--warning); padding:5px 10px; font-size:0.8rem;" onclick="openEditKendaraan(<?= $k['id_kendaraan'] ?>, '<?= htmlspecialchars(addslashes($k['plat_nomor'])) ?>', '<?= $k['jenis_kendaraan'] ?>', '<?= htmlspecialchars(addslashes($k['warna'])) ?>', '<?= htmlspecialchars(addslashes($k['pemilik'])) ?>')">
                        <i class="fa-solid fa-edit"></i>
                    </button>
                    <a href="<?= BASE_URL ?>/kendaraan/hapus/<?= $k['id_kendaraan'] ?>" class="btn-primary" style="background:var(--danger); padding:5px 10px; font-size:0.8rem;" onclick="return confirm('Menghapus kendaraan akan mempengaruhi history transaksi, Yakin?');">
                        <i class="fa-solid fa-trash"></i>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
function openEditKendaraan(id, plat, jenis, warna, pemilik) {
    document.getElementById('edit_id_kendaraan').value = id;
    document.getElementById('edit_plat_nomor').value = plat;
    document.getElementById('edit_jenis_kendaraan').value = jenis;
    document.getElementById('edit_warna').value = warna;
    document.getElementById('edit_pemilik').value = pemilik;
    document.getElementById('modalEditKendaraan').style.display = 'block';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
}

document.getElementById('formEditKendaraan').onsubmit = function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    fetch('<?= BASE_URL ?>/kendaraan/ubah', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.status === 'success') {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: data.message,
                background: '#1e293b',
                color: '#fff',
                confirmButtonColor: '#6366f1'
            }).then(() => {
                location.reload();
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: data.message,
                background: '#1e293b',
                color: '#fff'
            });
        }
    });
};

window.onclick = function(event) {
    if (event.target.className === 'modal') {
        event.target.style.display = 'none';
    }
}
</script>
